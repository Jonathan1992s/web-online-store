export const DefaultComponent = () => {
    return (
        <div className="App">
            <h1>Page Not Found</h1>
        </div>
    );
}