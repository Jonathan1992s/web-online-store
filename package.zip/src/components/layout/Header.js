import React from 'react'
import '../../style/Header.css'
import {NavBar} from "./NavBar";
export const Header = () => {
    return (
        <>
            <div className="main-header">
                <h1>Online Store</h1>
            </div>
            <NavBar/>
        </>

    )
}
