import React from 'react'
import '../../style/Footer.css'
export const Footer = () => {
    return (
        <div className="footer">
            <h1>2023 @web.io </h1>
        </div>
    )
}
