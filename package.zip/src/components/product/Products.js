import {Link, useParams} from "react-router-dom"
import data from '../../data/products.json'
import '../../style/Product.css'
import React, {useCallback, useEffect, useState} from "react";


export const Product = ({product}) => {
    const key = 'order'
    const saveOrder = useCallback((product) => {
        let orderList = JSON.parse(localStorage.getItem(key));
        if (!orderList) {
            orderList = [];
            orderList.push({
                id: product.id,
                name: product.name,
                price: product.price.toFixed(2),
                quantity: 1
        })
            localStorage.setItem(key,JSON.stringify(orderList))
        } else {
            let flagFoundItem = false
            let updateOrderList = orderList.map(item => {
                if (item.id === product.id) {
                    flagFoundItem = true
                    return {...item, quantity: item.quantity + 1};
                }
                return item
            });
            if (!flagFoundItem) {
                updateOrderList.push({
                    id: product.id,
                    name: product.name,
                    price: product.price.toFixed(2),
                    quantity: 1
                })
            }

            console.log(updateOrderList)
            localStorage.setItem(key,JSON.stringify(updateOrderList))
        }

    }, []);

    return <>
        <div className='product'>
            <Link to={`/product/${product.id}`}><h2>{product.name}</h2></Link>
            <img src={`/products/${product.id}.png`} alt=""></img>
            <div className="info ">
                <p><span className="label">Precio: </span>{product.price.toFixed(2)}</p>
                <p><span className="label">Marca: </span>{product.brand}</p>
            </div>
            <button onClick={() => saveOrder(product)}> Agregar </button>
        </div>
    </>
}


export const ProductDetail = () => {
    const {id}  = useParams()
    const [ product, setProduct ] = useState({})
    useEffect(() => {
        setProduct(
            data[id-1]
        )
    }, [id])
    return <>
        <div className='product'>
            <h2>{product.name}</h2>
            <img src={`/products/${id}.png`} alt=""></img>
            <div className="info">
                <p><span className="label">Precio: </span>{product.price}</p>
                <p><span className="label">Marca: </span>{product.brand}</p>
            </div>
        </div>
    </>
}