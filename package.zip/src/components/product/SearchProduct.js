import React, { useState } from 'react';
import data from '../../data/products.json'
import '../../style/Product.css'



export const SearchProduct = () => {

    const [searchValue, setSearchValue] = useState('');


    const handleChange = event => {
        setSearchValue(event.target.value);
    };

    const filterList = list => {
        return list.filter(item => item.toLowerCase().includes(searchValue.toLowerCase()));
    };

    return (
        <div className="search-box">
            <input  type="text" value={searchValue} placeholder="buscar producto..." onChange={handleChange} />

        </div>
    );
}

/*

<ul>
                {filterList().map(item => (
                    <li key={item}>{item}</li>
                ))}
            </ul>
 */